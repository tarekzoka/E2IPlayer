NOTIFICATION_INFO = ''
class Dialog():
    def __init__(self):
        pass
    def select(titre,vid_list):
        return 0
        
    def notification(titre1,titre2,x1,x2,a):
        return ''  
        
class DialogProgressBG():
    def __init__(self):
        pass
        
    def create(a,b):
        return 0
        
    def update(a,b):
        return 0
        
    def close():
        return 0   

